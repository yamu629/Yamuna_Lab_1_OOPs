package BookingMain;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
import BookingMain.*;

public class BookingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int option=chooseMenu();
		
		BookingRequest request=new BookingRequest();
		//Action based on menu option
		while(option!=4) {
			//1 means do booking
			if(option==1) { 
				System.out.println("Enter Requirement:");
				Scanner obj=new Scanner(System.in);
				String req1=obj.nextLine();
				
				String room=request.createRequest(req1);
//				System.out.println(room+" "+req1);
				if(room.isEmpty()) {
					String[] req2=req1.split(" ");
					System.out.println(req2[0]+" "+req2[1]+" "+req2[2]+" room not available");
				}
			}
			//2 means display not booked rooms
			else if(option==2) {
				request.displayRoomsAvailable();
				
			}
			//3 means cancel booking
			else if (option==3) {
				System.out.print("Enter room number to cancel booking:");
				Scanner obj=new Scanner(System.in);
				String req1=obj.nextLine();
				if(request.cancelRequest(req1)==false) {
					System.out.println("*********Cancel unsuccessful***********");
				}
				else {
					System.out.println("********Cancelled successfully********");
				}
			}
			else if(option!=4) {
				System.out.println("Invalid option");
			}
			//Display menu to choose option
			option=chooseMenu();
				
			}
		System.out.println("******Exit***********");
		System.exit(0);
			
		}
	
	static int chooseMenu(){
		System.out.println("Menu:\n1.Create booking request\n2.List available rooms\n3.Cancel booking\n4.Exit");
		System.out.print("Enter your choice: ");
		Scanner scan=new Scanner(System.in);
		return(scan.nextInt());
	}

}
