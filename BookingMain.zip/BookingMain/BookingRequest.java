package BookingMain;
import java.util.*;

public class BookingRequest extends Room{
	//create request to book
	public String createRequest(String req) {
		String [] req1=req.split(" ");
		//Converting requirement string to array of string
		for(int i=0;i<req1.length;i++) {
			req1[i]=new String(req1[i].toCharArray());
		}
		//flag to check if room found
		boolean found_flag=false;
		
		String room="";
		for(int i=0;i<rooms.length;i++) {
			//check if occupancy match and ac condition match
			if(req1[0].toLowerCase().equals(rooms[i][1])&&
					req1[2].toLowerCase().equals(rooms[i][2])
					) {
				
				
				if(req1.length==3 && req1[1].toLowerCase().equals("occupancy")) {
					if(get_RoomStatus(rooms[i][0])==false){
						
						found_flag=true;
						room=rooms[i][0];
						break;
					}
				}
				else if(req1.length==5 && req1[1].toLowerCase().equals("occupancy") && req1[4].toLowerCase().equals("floor")) {
					if(req1[3].toLowerCase().equals(rooms[i][3])&&get_RoomStatus(rooms[i][0])==false) {
						found_flag=true;
						room=rooms[i][0];
						break;
					}
				}
				
			}
		}
		//Show details if room found and return room to main
		if(found_flag==true) {
			show_RoomDetails(room);
			set_RoomStatus(room,true);
		}
		return room;
	}
	//cancel booking of any room
	public boolean cancelRequest(String room) {
		for(int i=0;i<rooms.length;i++) {
			if(rooms[i][0].equals(room) && get_RoomStatus(rooms[i][0])==true) {
				if(set_RoomStatus(rooms[i][0],false)==true) {
					return true;
				}
			}
		}
		return false;
		
	}
	//display rooms that are not yet booked
	public void displayRoomsAvailable() {
		for(int i=0;i<rooms.length;i++) {
			if(get_RoomStatus(rooms[i][0])==false) {
				show_RoomDetails(rooms[i][0]);
			}
		}
	}

}
