  package BookingMain;
  import java.util.*;

public class Room {
	//store room details like occupancy,ac condition,floor
	protected String[][] rooms= {{"101","single" , "ac","first"},
						{"102","double", "ac","first"},
						{"103","double", "non-ac","first"},
						{"201","single", "ac","second"},
						{"202","single", "non-ac","second"},
						{"203","double", "ac","second"},
						{"204","triple", "ac","second"}};
								
	//set booked status for room
	private HashMap<String, Boolean> bookedMap=new HashMap<String,Boolean>();
	Room()
	{
		for(int i=0;i<rooms.length;i++) {
			bookedMap.put(rooms[i][0], false);
		}
	}
	//return price of a particular room
	protected int get_Price(String room) {
		int price=0;
		for (int i=0;i<rooms.length;i++){
			if(rooms[i][0].equals(room)) {
				if(rooms[i][2].equals("ac")) {
					price= price+1000;
				}
				if(rooms[i][1].equals("single")) {
					price= price+2000;
					System.out.println(rooms[i][1]);
					break;
				}
				else if(rooms[i][1].equals("double")) {
					price=price+3000;
					break;
				}
				else if(rooms[i][1].equals("triple")) {
					price=price+4000;
					break;
				}
			}
		}
		
		return price;
	}
	//return booked status of room
	public boolean get_RoomStatus(String room) {
		
		return bookedMap.get(room);
	}
	//set booked status of room
	protected boolean set_RoomStatus(String room,boolean status) {
		return bookedMap.replace(room,status);
	}
	
	public void show_RoomDetails(String room) {
		for(int i=0;i<rooms.length;i++) {
			String aircond="non-air conditioned";
			if(rooms[i][2].equals("ac")) {
				aircond="air conditioned";
			}
			if(rooms[i][0].equals(room)) {
				System.out.println("Room number: "+rooms[i][0]+", "+rooms[i][3]+" floor, "+aircond+", "+rooms[i][1]+" occupancy, estimated: Rs."+get_Price(rooms[i][0])+"/ day");
			}	
		}
	}
	

}
