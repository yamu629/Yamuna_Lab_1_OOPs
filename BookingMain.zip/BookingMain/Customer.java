package BookingMain;
import java.util.*;

public class Customer {
	private Map<String,String> custNameMap= new HashMap<String,String>();//custmail,custname
	private Map<String,String> custNumMap= new HashMap<String,String>();//custmail,custcontactnum
	private Map<String,String> roomNumMap=new HashMap<String,String>();//room_num,custmail
	List<String> emailList=new ArrayList<String>();
	Customer(){
		System.out.print("Enter customer name: ");
		Scanner obj=new Scanner(System.in);
		String custName=obj.nextLine();
		System.out.print("Enter contact number: ");
		obj=new Scanner(System.in);
		String contactNum=obj.nextLine();
		System.out.print("Enter contact email: ");
		obj=new Scanner(System.in);
		String contactEmail=obj.nextLine();
		boolean Numflag=true;
		try {
			int num=Integer.parseInt(contactNum);
		}
		catch(Exception e){
			Numflag=false;
		}
		while(contactEmail.isEmpty()||contactEmail.indexOf('@')==-1)  {
			if(contactEmail.indexOf('@')==-1) {
				System.out.println("No or multiple @ in mail ID");
			}
			else {
				System.out.println("Email cannot be empty.");
			}
			System.out.print("Enter contact email: ");
			obj=new Scanner(System.in);
			contactNum=obj.nextLine();
		}
		if(isCustomer(contactEmail)==false) {
			
			while(custName.isEmpty()) {
				System.out.println("Pls provide name for "+contactEmail);
				System.out.print("Enter customer name: ");
				obj=new Scanner(System.in);
				custName=obj.nextLine();
			}
			if (contactNum.length()!=10 && Numflag!=true) {
					add_Customer(contactEmail,custName);
					System.out.print("Invalid contact number");
			}
			else {
					add_Customer(contactEmail,custName,contactNum);
			}
			System.out.print("Customer added.");
			
			
		}
		else {
			System.out.println("Customer details exist. Not adding new one.");
		}
		
	obj.close();	
	}
	private void add_Customer(String mail, String name) {
		if(!emailList.contains(mail)) {
		emailList.add(mail);
		custNameMap.put(mail, name);
		}
		
	}
	
	private void add_Customer(String mail,String name,String mobile){
		if(!emailList.contains(mail)) {
		emailList.add(mail);
		custNameMap.put(mail, name);
		custNumMap.put(mail, mobile);
		}
		
	}
	private boolean isCustomer(String mail) {
		if(emailList.contains(mail)) {
			return true;
		}
		return false;
			
	}
	public void show_Customer(String mail) {
		
		System.out.println(custNameMap.get(mail)+" "+custNumMap.get(mail)+" "+mail);
	}
	public void set_userRooms(String mail, String room) {
			roomNumMap.put(room, mail);
		
	}
	public String get_RoomDetails(String room) {
		return(roomNumMap.get(room));
	}
}
